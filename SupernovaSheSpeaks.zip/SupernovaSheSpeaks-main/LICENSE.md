Copyright Supernova: She Speaks [2025]. All rights reserved.

This project is for demonstration and portfolio purposes only.  
No part of this work may be used, copied, modified, or redistributed in any form without express written permission from the author.

Patent rights may be applied for. This work is not currently licensed for open source use.
